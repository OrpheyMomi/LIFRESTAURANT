<?php

session_start();

define("URI", "http://localhost/dashboard/LIF/restaurant/");
define("ROOT", str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']));
require_once ROOT . "autoload.php";
$params = explode("/", $_GET['p']);

if ($params[0] != "") {

    $nomController = ucfirst($params[0]);
    if (file_exists(ROOT . "controllers/" . $nomController . ".php")) { 
        $controller = new $nomController(); 
        $action = isset($params[1]) ? $params[1] : 'index';
        if (method_exists($controller, $action)) {
            
            array_shift($params);
            
            array_shift($params);
           
            call_user_func_array([$controller, $action], $params);
            return;

        }
        header("Location: " . URI . "restaurants/index");
        return;

    } else {
        header("Location: " . URI . "restaurants/index");
        return;

    }

} else {
    header("Location: " . URI . "restaurants/index");
}

?>


