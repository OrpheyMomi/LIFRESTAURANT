<?php

class Panier
{

    public function __construct()
    {
        if (!isset($_SESSION['Paniers'])) {
            $_SESSION['Paniers'] = [];
        }
    }

    public function ajouter($id, $quantite)
    {
        $_SESSION['Paniers'][$id] = $quantite;
        

    }

    public function supprimer($id)
    {
        unset($_SESSION['Paniers'][$id]);
    }

    public function getAll()
    {
        $restaurants = [];
        $restaurant = new Restaurant();
        foreach ($_SESSION['Paniers'] as $key => $quantite) {
            $data = ['id_menu' => $key];

            
            $restaurants[] = [$quantite, $restaurant->getOneById($data)];
        }
        return $restaurants;
    }


}