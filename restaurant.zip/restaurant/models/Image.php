<?php

class Image extends Model{

    public function __construct(){
        parent:: __construct();
    }

    public function ajouter($data){
        $this->sql= "insert into Image(id_menu  ,
        chemin) value (:id_menu  ,
        :chemin)";

  return $this->getLines($data, null);
    }
}


?>