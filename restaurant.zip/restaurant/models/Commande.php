<?php

class Commande extends Model{
    public function __construct(){
        parent::__construct();
        $this->table = "Commande";
    }
public function getCommandes(){
    $this->sql = "select c.*, u.nom, u.prenom,m.description,m.prix    FROM " . $this->table . " c LEFT JOIN Utilisateur u ON c.id_utilisateur = u.id_utilisateur
    LEFT JOIN MenuCommande mc ON c.id_commande = mc.id_commande
    LEFT JOIN Menu m ON mc.id_menu = m.id_menu";
    return $this->getLines();
}

public function valider($data){
    $this->sql = "insert into " . $this->table .   " ( prix,quantite,date_commande)   value ( :prix, :quantite, :date_commande)";
    return $this->getLines($data,null);
}


public function getDetailsCommande($id_commande) {
    // Préparez la requête SQL pour récupérer les détails de la commande
    $this->sql = "SELECT c.id_commande, c.quantite, c.date_commande, u.nom AS nom_utilisateur, u.prenom AS prenom_utilisateur, u.email AS email_utilisateur, c.prix AS prix_total
                  FROM Commande c
                  LEFT JOIN Utilisateur u ON c.id_utilisateur = u.id_utilisateur
                  WHERE c.id_commande = :id_commande";
    $this->params = array(':id_commande' => $id_commande); // Passer l'ID de la commande ici
    return $this->getLines();
}


    // // Exécutez la requête avec le paramètre d'ID de commande
    // $params = array(':id_commande' => $id_commande);
    // $result = $this->getLines($params);

    // // Vérifiez si des données ont été trouvées
    // if ($result) {
    //     // Retournez les détails de la commande
    //     return $result[0]; // Nous attendons seulement une seule ligne de résultat
    // } else {
    //     // Si aucune donnée n'est trouvée pour cette commande, retournez null ou une valeur indiquant une erreur
    //     return null;
    // }
}




?>


