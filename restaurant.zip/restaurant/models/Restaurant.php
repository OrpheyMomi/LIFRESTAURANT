<?php

class Restaurant extends Model{
    public function __construct(){
        parent::__construct();
        $this->table = "Menu";
    }

    public function ajouter($data){
        $this->sql = "insert into " . $this->table .   " (description, prix)   value (:description, :prix)";
        return $this->getLines($data,null);
    }


    
    public function getRestaurants()
    {
        $this->sql = "select m.*,i.chemin from " . $this->table . " 
        m left JOIN Image i on m.id_menu = i.id_menu;";
        return $this->getLines();
    }

    public function supprimer($data)
    {
        $this->sql = "delete from " . $this->table . " where id_menu = :id_menu";
        return $this->getLines($data, null);
    }



    public function getOneById($data)
    {
        $this->sql = "select m.*,i.chemin from " . $this->table . " 
        m left JOIN Image i on m.id_menu = i.id_menu where m.id_menu = :id_menu";

        return $this->getLines($data, true);
    
}

public function modifier($data)
{
    $this->sql = "UPDATE " . $this->table . " SET description = :description, prix = :prix WHERE id_menu = :id_menu";
    return $this->getLines($data, null);
}


}

?>