-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 09:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifrestaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `adresse`
--

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL,
  `rue` varchar(20) NOT NULL,
  `ville` varchar(20) NOT NULL,
  `code_postal` varchar(20) NOT NULL,
  `pays` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL,
  `numero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adresseutilisateur`
--

CREATE TABLE `adresseutilisateur` (
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_adresse` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `id_utilisateur` int(11) DEFAULT NULL,
  `prix` varchar(20) NOT NULL,
  `quantite` int(11) NOT NULL,
  `date_commande` date NOT NULL,
  `mode_paiement` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `commande`
--

INSERT INTO `commande` (`id_commande`, `id_utilisateur`, `prix`, `quantite`, `date_commande`, `mode_paiement`) VALUES
(1, NULL, '34.478955', 2, '2024-08-11', NULL),
(2, NULL, '34.478955', 2, '2024-08-12', NULL),
(3, NULL, '34.478955', 2, '2024-08-12', NULL),
(4, NULL, '34.478955', 2, '2024-08-12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id_image` int(11) NOT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `chemin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id_image`, `id_menu`, `chemin`) VALUES
(7, 1, 'assets/images/a.jpeg'),
(8, 2, 'assets/images/b.jpeg'),
(9, 3, 'assets/images/ba.jpeg'),
(10, 4, 'assets/images/c.jpeg'),
(11, 5, 'assets/images/crev.jpeg'),
(12, 6, 'assets/images/da.jpeg'),
(13, 7, 'assets/images/e.jpeg'),
(14, 8, 'assets/images/fri.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `prix` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `description`, `prix`) VALUES
(1, 'Plat traditionnel avec du riz et ragoût de viande et carottes', '12.99'),
(2, 'Ragoût épicé avec crabe et riz blanc', '15.99'),
(3, 'Poulet rôti avec bananes plantains, tomates et oignons', '18.99'),
(4, 'Riz Djon Djon accompagner de poulet frit et pikliz', '15.99'),
(5, 'Crevette frite', '15.99'),
(6, 'Poisson avec bananes plantains, tomates et oignons', '18.99'),
(7, 'Riz coller au poir', '15.99'),
(8, 'Griot de chevre', '15.99');

-- --------------------------------------------------------

--
-- Table structure for table `menucommande`
--

CREATE TABLE `menucommande` (
  `id_commande` int(11) DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `quantite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id_role`, `description`) VALUES
(1, 'admin'),
(2, 'client');

-- --------------------------------------------------------

--
-- Table structure for table `roleutilisateur`
--

CREATE TABLE `roleutilisateur` (
  `id_utilisateur` int(11) DEFAULT NULL,
  `id_role` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `date_naissance` date NOT NULL,
  `email` varchar(20) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `id_role` int(11) DEFAULT NULL,
  `mot_de_passe` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `nom`, `prenom`, `date_naissance`, `email`, `telephone`, `id_role`, `mot_de_passe`) VALUES
(1, 'Jeffie', 'Abda', '1980-01-01', 'darline@gmail.com', '123456789', 1, '$2y$10$f9tLn/YRr23kDT1n6eAfwugQFzRFYN4gC.orFc/5UteJpa.HHQJzq'),
(3, 'MOMI LEUDJIE', 'Orphey Virgil', '2024-08-13', 'chelsea@gmail.com', '691075510', 1, '$2y$10$qhAmXtAWpTA5ooTguOGRPec.S53ikKg.Wj9PmDW4/U6XwA2WEt2Bi'),
(4, 'Miriam', 'Toh Afor', '2024-08-12', 'abc@gmail.com', '23456789', 2, '$2y$10$4X7oVdS9NUpTJGAJ0SAirOkMbMLGiDcXQhOTGHgQNy2eo/gjZbIF2'),
(6, 'Peter', 'Marchand', '2024-08-12', 'peter@gmail.com', '345678', 2, '$2y$10$DsOnIky.tg3lVnkcjzcvterwBWKGnHeViz187Hg5ZSNe6dRGYFo6S'),
(7, 'Virgil', 'Momi', '2024-08-12', 'yo@gmail.com', '4383040710', 2, '$2y$10$gKHTcP2RQsLll85w2.7txOVhAd9NuoWUFLrqXHZPH8ew2Aw6wE.u6'),
(8, 'Virgil', 'Momi', '2024-08-12', 'chel@gmail.com', '4383040710', 2, '$2y$10$JRqEXxXNLBtTYePvbz5RVONbuvyZTidWyoMD5x0RgT1D20HLt1SYS'),
(9, 'nouchi', 'yo', '2024-08-13', 'nouch@gmail.com', '098765', 2, '$2y$10$Hyl1gkEJhFCLKxIIGSn4judT73qnssl8L.iK76Ek9XmoVVUt5omn6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`id_adresse`);

--
-- Indexes for table `adresseutilisateur`
--
ALTER TABLE `adresseutilisateur`
  ADD KEY `fk_adresse_utilisateur` (`id_adresse`),
  ADD KEY `fk_utilisateur_adresse` (`id_utilisateur`);

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id_image`),
  ADD KEY `fk_image_menu` (`id_menu`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `menucommande`
--
ALTER TABLE `menucommande`
  ADD KEY `fk_menu_commande` (`id_menu`),
  ADD KEY `fk_commande_menu` (`id_commande`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- Indexes for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`),
  ADD KEY `fk_role_utilisateur` (`id_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adresse`
--
ALTER TABLE `adresse`
  MODIFY `id_adresse` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id_image` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adresseutilisateur`
--
ALTER TABLE `adresseutilisateur`
  ADD CONSTRAINT `fk_adresse_utilisateur` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id_adresse`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_utilisateur_adresse` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`id_utilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `fk_image_menu` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`);

--
-- Constraints for table `menucommande`
--
ALTER TABLE `menucommande`
  ADD CONSTRAINT `fk_commande_menu` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`),
  ADD CONSTRAINT `fk_menu_commande` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`);

--
-- Constraints for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `fk_role_utilisateur` FOREIGN KEY (`id_role`) REFERENCES `role` (`id_role`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
