Présentation du Projet BY MOMI LEUDJIE ORPHEY VIRGIL ET Merisier Peter Marchand
1. Introduction
Nom du Projet : LIFE RESTAURANT
Description :
Ce projet est une application web pour la gestion d'un restaurant. Elle permet aux utilisateurs de s'inscrire, de se connecter, de naviguer dans les menus, de passer des commandes, etc.
Le projet utilise une architecture MVC (Modèle-Vue-Contrôleur) pour séparer les préoccupations et organiser le code de manière modulaire et réutilisable.

2. Objectifs
Créer une plateforme intuitive pour les clients afin de consulter les menus, passer des commandes, et interagir avec le restaurant.
Gérer les utilisateurs avec différents rôles, notamment les administrateurs et les clients.
Permettre une gestion facile des menus, commandes, utilisateurs, et rôles via une interface administrateur.
3. Architecture du Projet
Modèle-Vue-Contrôleur (MVC) :
Modèle (Model) : Représente les données et les règles métiers (ex: Utilisateurs, Menus, Commandes).
Vue (View) : Interface utilisateur qui affiche les données provenant du Modèle.
Contrôleur (Controller) : Intermédiaire entre le Modèle et la Vue. Gère la logique d'application.
4. Diagrammes de Classe
4.1 Diagramme de Classe Principal
Classes principales :
Utilisateur
Menu
Commande
Role
Adresse
Image
Diagramme de classe UML
Je vais vous décrire comment chaque classe est définie et leurs relations.

Classe Utilisateur :

Attributs :
id_utilisateur : int
nom : varchar(20)
prenom : varchar(20)
date_naissance : date
email : varchar(20)
telephone : varchar(20)
id_role : int
mot_de_passe : text
Relations :
Relation avec Role : Plusieurs utilisateurs peuvent avoir un rôle spécifique.
Relation avec Commande : Un utilisateur peut passer plusieurs commandes.
Relation avec Adresse : Un utilisateur peut avoir plusieurs adresses.
Classe Role :

Attributs :
id_role : int
description : varchar(50)
Relations :
Relation avec Utilisateur : Un rôle peut être associé à plusieurs utilisateurs.
Classe Menu :

Attributs :
id_menu : int
description : text
prix : varchar(20)
Relations :
Relation avec Image : Un menu peut avoir plusieurs images associées.
Relation avec Commande : Un menu peut être associé à plusieurs commandes.
Classe Commande :

Attributs :
id_commande : int
date_commande : date
etat : varchar(20)
id_utilisateur : int
id_menu : int
Relations :
Relation avec Utilisateur : Une commande est passée par un utilisateur.
Relation avec Menu : Une commande contient un ou plusieurs menus.
Classe Adresse :

Attributs :
id_adresse : int
rue : varchar(50)
ville : varchar(20)
code_postal : varchar(10)
id_utilisateur : int
Relations :
Relation avec Utilisateur : Une adresse est associée à un utilisateur.
Classe Image :

Attributs :
id_image : int
chemin : varchar(255)
id_menu : int
Relations :
Relation avec Menu : Une image est associée à un menu.
5. Relations entre les Classes
Utilisateur - Role : Un utilisateur a un rôle (1-N).
Utilisateur - Commande : Un utilisateur peut passer plusieurs commandes (1-N).
Menu - Commande : Une commande peut contenir plusieurs menus (1-N).
Menu - Image : Un menu peut avoir plusieurs images (1-N).
Utilisateur - Adresse : Un utilisateur peut avoir plusieurs adresses (1-N).
6. Scénarios d'Utilisation
Inscription et Connexion : Un utilisateur s'inscrit, puis se connecte pour accéder aux fonctionnalités de l'application.
Gestion des Menus : Les administrateurs peuvent ajouter, modifier ou supprimer des menus.
Passation de Commande : Les utilisateurs passent des commandes à partir des menus disponibles.
8. Conclusion
Avantages :
Séparation des préoccupations via l'architecture MVC.
Gestion centralisée des utilisateurs, menus et commandes.
9.LIEN VERS GITHUB
https://github.com/OrpheyMomi/LIFRESTAURANT
MERCI
