<?php

class Auths extends Controllers{
    public function inscription(){

        if(isset($_SESSION["Utilisateur"])){
            header("Location: " . URI . "restaurants/index");
           
        }
       
       if(isset($_POST["submit"])){
        if(!($this->estVide($_POST))){
            if($_POST["mot_de_passe"] === $_POST["c_mot_de_passe"]){
                $_POST["mot_de_passe"] = password_hash($_POST["mot_de_passe"],PASSWORD_DEFAULT);
            
                unset($_POST["c_mot_de_passe"]);
                unset($_POST["submit"]);
                $_POST["id_role"]= 2;

                $oAuth=new Auth();
                $oAuth->inscription($_POST);

                header("Location: " . URI . "restaurants/accueil");
                exit();

        
            }
            
        }
        
       }
       $this->render("register");
    }
    public function connexion(){

        if(isset($_SESSION["Utilisateur"])){
            header("Location: " . URI . "restaurants/index");
           
        }

        if(isset($_POST['submit'])){
            if(!$this->estVide($_POST)){
                $mot_de_passe = $_POST["mot_de_passe"];
                unset($_POST["mot_de_passe"],$_POST["submit"]);
                $auth = new Auth();
                $user = $auth->findUserByEmail($_POST);
               if($user){
                    if(password_verify($mot_de_passe,$user->mot_de_passe)){
                        $_SESSION["Utilisateur"] = $user;
                        header("Location: " . URI . "restaurants/accueil");
                    }else{
                        $this->erreurs["emPass"]="Email or password incorrect";
                        $this->render('login',$this->erreurs);
                       
                    }
               }else{
                $this->erreurs["emPass"]="Email or password incorrect";
                $this->render('login',$this->erreurs);
               }
            }
            else{
                $this->erreurs["emPass"]="Email or password incorrect";
                $this->render('login',$this->erreurs);
            }

        }
       $this->render('login');
    }

    public function index(){
        if(!isset($_COOKIE["Abda"])){
            setcookie("Abda", "Abda est là!", time() + (60 * 60 * 24));
        }
        echo "Je suis a index";

        var_dump($_SESSION["Utilisateur"]);
    }

    public function deconnexion(){
        unset($_SESSION["Utilisateur"]);
        header("Location: " . URI . "restaurants/accueil");
           
    }


    public function afficherUtilisateur() {
        $auth = new Auth();
        $user = $auth->getAllUtilisateur();
        $this->render('user', compact('user'));
    }
    
    public function supprimerUtilisateur($id_utilisateur) {
        if (isset($_SESSION['Utilisateur']) && strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
            if (is_numeric($id_utilisateur)) {
                $auth = new Auth();
                $auth->supprimerUtilisateur(compact('id_utilisateur'));
                header('Location: ' . URI . 'auth/user');
                
            }
        }else{
        header("Location: " . URI . "auth/user");
    }
}

    
    public function ajouterUtilisateur() {
        if(isset($_POST["submit"])) {
            if(!($this->estVide($_POST))) {
                if($_POST["mot_de_passe"] === $_POST["c_mot_de_passe"]) {
                    $_POST["mot_de_passe"] = password_hash($_POST["mot_de_passe"], PASSWORD_DEFAULT);
                    unset($_POST["c_mot_de_passe"], $_POST["submit"]);
    
                    // Utilisez la valeur du champ 'role' pour déterminer le rôle de l'utilisateur
                    if($_POST['id_role'] === 'admin') {
                        $_POST["id_role"] = Auth::ADMIN;
                    } else {
                        $_POST["id_role"] = Auth::CLIENT;
                    }
    
                    $auth = new Auth();
                    $auth->ajoutUser($_POST);
                    header("Location: " . URI . "auth/user");
                    exit();
                }
            }
        }
        $this->render("ajoutUser");
    }
    

//     public function modifierUser($id_utilisateur)
//     {
//         if (isset($_SESSION['Utilisateur']) && strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
//             if (is_numeric($id_utilisateur)) {
//                 if (isset($_POST['submit'])) {
//                     if (!$this->estVide($_POST)) {
//                         $data = [
//                             "id_utilisateur" => $id_utilisateur,
//                             "nom" => $_POST['nom'],
//                             "prenom" => $_POST['prenom'],
//                             "email" =>  $_POST['email'],
//                            "date_naissance" =>  $_POST['date_naissance'],
//                            "telephone" =>  $_POST['telephone']

//                         "mot_de_passe" =>  $_POST['mot_de_passe']
                           
//                         ];
//                         $auth = new Auth();
//                         $auth->modifierUser($data);
//                         header('Location: ' . URI . 'auths/user');
                       
//                     }
//                 }
//                 $this->render('modifierUser', compact('id_utilisateur'));
//                 return;
//             }
//         }
    
//         header("Location: " . URI . "auths/user");
       
//     } 
  
//}

public function modifierUser($id_utilisateur) {
    if (isset($_POST['submit'])) {
        if (!$this->estVide($_POST)) {
            $auth = new Auth();
            $data = [
                "id_utilisateur" => $id_utilisateur,
                "nom" => $_POST['nom'],
                "prenom" => $_POST['prenom'],
                "email" => $_POST['email'],
                "date_naissance" => $_POST['date_naissance'],
                "telephone" => $_POST['telephone'],
                 "mot_de_passe" => $_POST['mot_de_passe']
                
            ];
            $auth->modifierUser($data);
            header("Location: " . URI . "auth/user");
            return;
        }
    }
    
    $auth = new Auth();
    // $id_utilisateur["id_utilisateur"]=$id_utilisateur;
    $utilisateur = $auth->findUserById(compact('id_utilisateur'));

    var_dump($utilisateur);
   $this->render('modifierUser', compact('utilisateur'));
}

}


?>