<?php
class Commandes extends Controllers{

    public function commander()
    {

        $commande = new Commande();
        $commandes = $commande->getCommandes();
        $this->render("commander", compact('commandes'));
    }


    public function valider(){

        // Vérifier si les données du formulaire ont été soumises
        if(isset($_POST["valider"])){
            
            // Récupérer les informations nécessaires pour la commande
            $prix = $_POST["total"];
            $quantite = $_POST["quantiteTotale"];
            $date_commande = date("Y-m-d"); // Date de la commande (à adapter selon vos besoins)
    
            // Créer un tableau avec les données de la commande
            $data = array(
                "prix" => $prix,
                "quantite" => $quantite,
                "date_commande" => $date_commande
            );
    
            // Ajouter la commande à la base de données
            $commande = new Commande();
            $commande->valider($data);
    
            // Vider le panier après la validation de la commande (à adapter selon votre implémentation)
            // Ici, vous pouvez ajouter la logique pour vider le panier en fonction de votre application
            
            // Rediriger l'utilisateur vers une page de confirmation ou une autre page appropriée
            header("Location: " . URI . "commandes/commander");
            exit();
        }
        
        // Si les données du formulaire n'ont pas été soumises ou si la validation échoue, vous pouvez rediriger l'utilisateur
        // vers une page d'erreur ou afficher un message d'erreur, selon votre implémentation
    }
    
      
    public function details($id_commande) {
        // Récupérer les détails de la commande en fonction de son ID
        $commande = new Commande();
        $details_commande = $commande->getDetailsCommande($id_commande); // Passer l'ID de la commande ici
    
        // Passer les détails de la commande à la vue appropriée
        $this->render("details_commande", compact('details_commande'));
    }
    

}

?>