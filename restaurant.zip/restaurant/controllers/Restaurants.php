<?php

class Restaurants extends Controllers
{
    public function index()
    {

        $restaurant = new Restaurant();
        $restaurants = $restaurant->getRestaurants();
        $this->render("index", compact('restaurants'));
    }

   
   
    public function ajouter()
    {
        if (isset($_SESSION['Utilisateur'])) {
            if (strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
                $id_menu = -1;
                if (isset($_POST['submit'])) {
                    if (!$this->estVide($_POST)) {
                        unset($_POST['submit']);
                        $restaurant = new Restaurant();
                        global $oPDO;
                        $restaurant->ajouter($_POST);
                        $id_menu = $oPDO->lastInsertId();
                        
                    }
                    $this->ajouterImage($id_menu);
                    header("Location: " . URI . "restaurants/index");
                    return;


                }
                $this->render('ajouter');
            } else {
                header("Location: " . URI . "restaurants/index");
            }

        } else {
            header("Location: " . URI . "restaurants/index");
        }


    }

    
    private function ajouterImage($id_menu)
    {
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
            $image_name = $_FILES["image"]["name"];
            $image_tmp = $_FILES["image"]["tmp_name"];
            $image_destination = "assets/images/" . basename($image_name); // Chemin de destination du fichier sur le serveur


            $image_type = strtolower(pathinfo($image_destination, PATHINFO_EXTENSION));

            if (!in_array($image_type, array("jpg", "jpeg", "png", "gif"))) {
                echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
                exit();
            }
            if (move_uploaded_file($image_tmp, ROOT . $image_destination)) {
                $image = new Image();
                $data = [
                    "id_menu" => $id_menu,
                    "chemin" => $image_destination
                ];
                $image->ajouter($data);
            }
        }
    }



    public function supprimer($id_menu)
{

    if (isset($_SESSION['Utilisateur']) && strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
        if (is_numeric($id_menu)) {
            $restaurant = new Restaurant();
            $restaurant->supprimer(compact('id_menu'));
            header('Location: ' . URI . 'restaurants/index');
        }
    } else {
    
        header("Location: " . URI . "restaurants/index");
    }
}

public function accueil()
{
   
    $restaurant = new Restaurant();
    $restaurants = $restaurant->getRestaurants();
    $this->render("accueil", compact('restaurants'));
}


public function modifier($id_menu)
{
    if (isset($_SESSION['Utilisateur']) && strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
        if (is_numeric($id_menu)) {
            if (isset($_POST['submit'])) {
                if (!$this->estVide($_POST)) {
                    $data = [
                        "id_menu" => $id_menu,
                        "description" => $_POST['newName'], 
                        "prix" => $_POST['category'] 
                        
                    ];
                    $restaurant = new Restaurant();
                    $restaurant->modifier($data);
                    header('Location: ' . URI . 'restaurants/index');
                   
                }
            }
            $this->render('modifier', compact('id_menu'));
            return;
        }
    }

    header("Location: " . URI . "restaurants/index");
   
}



}


?>