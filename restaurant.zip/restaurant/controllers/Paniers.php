<?php

class Paniers extends Controllers
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $panier = new Panier();
        $restaurants = $panier->getAll();
        $this->render('index', compact('restaurants'));

    }

    public function test($data)
    {
        echo $data;
//        echo "Je suis test";

    }

    public function ajouter($id_menu)
    {
        if (is_numeric($id_menu)) {
            $panier = new Panier();
            $panier->ajouter($id_menu,1);
        }
        header('Location: ' . URI . 'paniers/accueil');


    }

    public function modifier($id_menu)
    {
        if (is_numeric($id_menu)) {
            $quantite = $_POST['quantite'];
            if (is_numeric($quantite)) {
                $panier = new Panier();
                $panier->ajouter($id_menu, $quantite);
            }
        }
        header("Location: " . URI . "paniers/index");

    }

    public function supprimer($id_menu)
    {
        if (is_numeric($id_menu)) {
            $panier = new Panier();
            $panier->supprimer($id_menu);
        }
        header("Location: " . URI . "paniers/index");
    }

}

?>