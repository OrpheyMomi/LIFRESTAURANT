<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des commandes</title>
</head>
<body>
    <div class="container mt-5">
        <h1>Liste des commandes</h1>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Utilisateur</th>
                    <!-- <th scope="col">Prix</th> -->
                    <th scope="col">Quantité</th>
                    <th scope="col">Date de commande</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

            <?php foreach ($commandes as $commande): ?>
                    <tr>
                        <td><?= $commande->id_commande; ?></td>
                        <td><?= $commande->nom . ' ' . $commande->prenom; ?></td>
                        <td><?= $commande->quantite; ?></td>
                        <td><?= $commande->date_commande; ?></td>
                        <td>
    <a href="<?= URI . 'commandes/details/' . $commande->id_commande; ?>" class="btn btn-sm btn-info">Afficher les détails</a>
</td>

                    </tr>
                <?php endforeach; ?>
               
            </tbody>
        </table>
    </div>
</body>
</html>
