<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de la commande</title>
</head>
<body>
    <div class="container mt-5">
        <h1>Détails de la commande</h1>

        <p>Numéro de commande : <?= $details_commande->id_commande; ?></p>
        <p>Quantité : <?= $details_commande->quantite; ?></p>
        <p>Date de commande : <?= $details_commande->date_commande; ?></p>
        <p>Utilisateur : <?= $details_commande->nom_utilisateur . ' ' . $details_commande->prenom_utilisateur; ?></p>
        <p>E-mail de l'utilisateur : <?= $details_commande->email_utilisateur; ?></p>
        <p>Prix total : <?= $details_commande->prix_total; ?></p>

        <!-- Vous pouvez ajouter d'autres détails de la commande ici selon vos besoins -->
    </div>
</body>
</html>
