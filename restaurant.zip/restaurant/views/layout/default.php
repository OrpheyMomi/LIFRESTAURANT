<header>
    <?php
    require_once ROOT."views/public/header.php";
    ?>
</header>
<main>
    <?php 
    echo $contenu;
    ?>
</main>
<!-- <footer>
    <h3>je suis footer</h3>
</footer> -->
