
<form method="post" class="container">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nom: </label>
    <input type="text" class="form-control" name="nom">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Prenom:</label>
    <input type="text" class="form-control" name="prenom">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Email:</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Date de naissance:</label>
    <input type="date" class="form-control" name="date_naissance">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Telephone</label>
    <input type="text" class="form-control" name="telephone">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mot de passe:</label>
    <input type="password" class="form-control" name="mot_de_passe">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Confirmer mot de passe:</label>
    <input type="password" class="form-control" name="c_mot_de_passe">
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Enregistrer">
</form>