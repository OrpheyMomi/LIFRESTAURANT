<?php
//page d'inscription uniquement du html