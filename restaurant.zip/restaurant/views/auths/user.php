<?php require_once(ROOT . "views/public/header.php"); ?>

<div class="container mt-5">
    <h1>Liste des Utilisateurs</h1>

    <a class="btn btn-primary" href=<?= URI . "auths/ajouterUtilisateur" ?>>Ajouter</a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nom</th>
                <th scope="col">Prénom</th>
                <th scope="col">Date de Naissance</th>
                <th scope="col">Email</th>
                <th scope="col">Téléphone</th>
                <th scope="col">id_role</th>
                <th scope="col">Mot de passe</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($user as $utilisateur) { ?>
                <tr>
                    <th scope="row"><?= $utilisateur->id_utilisateur ?></th>
                    <td><?= $utilisateur->nom ?></td>
                    <td><?= $utilisateur->prenom ?></td>
                    <td><?= $utilisateur->date_naissance ?></td>
                    <td><?= $utilisateur->email ?></td>
                    <td><?= $utilisateur->telephone ?></td>
                    <td><?= $utilisateur->id_role ?></td>
                    <td><?= $utilisateur->mot_de_passe ?></td>
                    <td>

                    </a>
                    <a class="btn btn-sm btn-warning" href=<?= URI. 'auths/modifierUser/' .$utilisateur->id_utilisateur; ?>>
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <a class="btn btn-sm btn-danger" href=<?= URI . 'auths/supprimerUtilisateur/' . $utilisateur->id_utilisateur; ?>>
                        <i class="bi bi-trash3-fill"></i>
                    </a>
                       
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php require_once(ROOT . "views/public/footer.php"); ?>
