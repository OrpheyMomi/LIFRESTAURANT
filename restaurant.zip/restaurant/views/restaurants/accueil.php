<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
             background-color:  rgb(255, 236, 139);
        }

        header {
            background-color: black;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
            
        }

        .produits {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .produit {
            width: calc(25% - 20px);/* Pour afficher 3 produits par ligne */
            margin-bottom: 20px;
            background-color: black;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 10px;
            box-sizing: border-box;
        }

        .produit img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .logo img {
            width: 150px;
            height: auto;
        }
        

        main {
            padding: 20px;
        }

        .produit h3 {
            margin-top: 10px;
            font-size: 18px;
            text-align: center;
        }

        .produit p {
            margin-top: 5px;
            font-size: 16px;
            color: #555;
            text-align: center;
        }

        footer {
            background-color: black;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="<?= URI ?>assets/images/logo.png" alt="Logo">
        </div>
    </header>
    <main>
        <div class="container">
            <h1>Nos Produits</h1>
            <div class="produits">
                <?php foreach ($restaurants as $restaurant) { ?>
                    <div class="produit">
    <img src="<?= URI . $restaurant->chemin ?>" alt="<?= $restaurant->description ?>">
    <h3><?= $restaurant->description ?></h3>
    <p>Prix: <?= $restaurant->prix ?>$</p>

    <div class="text-center">
    <a class="btn btn-sm warning-emphasis" href=<?= URI . 'paniers/ajouter/' . $restaurant->id_menu; ?>><i class="bi bi-cart3"></i>
                       
                    </a>
                </div>
</div>
                <?php } ?>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Votre Nom</p>
    </footer>
</body>
</html>
