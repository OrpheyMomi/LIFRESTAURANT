


<div  methode="post" class="container mt-5">
    <h2>Ajouter Produit</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="productName">Description :</label>
            <input
                type="text"
                class="form-control"
                id="description"
                name="description"
                required
            />
        </div>
        <div class="form-group">
            <label for="productName">Prix:</label>
            <input
                type="text"
                class="form-control"
                id="prix"
                name="prix"
                required
            />
        </div>
        
       
      
        <div class="form-group">
            <label for="image" class="form-label">Choose an Image :</label>
            <input type="file" name="image" id="image" />
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Ajouter">

    </form>
</div>