<style>
    
    body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
             background-color:  rgb(255, 236, 139);
        }

        header {
            background-color: black;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .produit{
            background-color: black;
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
            
        }
    
    
    /* Style pour le tableau */
    .table {
        color: black; /* Couleur du texte */
    }

    .table th,
    .table td {
        border-color: rgb(255, 236, 139); /* Couleur de la bordure */
    }

    /* Style pour les boutons d'action */
 

    .btn-success:hover,
    .btn-warning:hover,
    .btn-danger:hover {
        background-color: black; /* Couleur de fond au survol */
        border-color: black; /* Couleur de la bordure au survol */
        color: rgb(255, 236, 139); /* Couleur du texte au survol */
    }


</style>



<div class="container mt-5">
    <h1>Liste d'articles</h1>

    <a class="btn btn-primary" href=<?= URI . "restaurants/ajouter" ?>>Ajouter</a>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Image</th>
            <th scope="col">Description</th>
            <th scope="col">Prix</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php

        $cmpt = 1;
        foreach ($restaurants as $restaurant) { ?>
        <div class="produit">
            <tr>
                <th scope="row"><?= $cmpt++; ?></th>
                <td>
                    <img height="100px" width="100px"
                         src=<?=
                    (isset($restaurant->chemin)) ?
                        URI . $restaurant->chemin :
                        URI . 'assets/télécharger .jpeg';

                    ?>></td>
                <td><?= $restaurant->description; ?></td>
                <td><?= $restaurant->prix; ?>$</td>
                
                
                <td>
                    <a class="btn btn-sm btn-success" href=<?= URI . 'paniers/ajouter/' . $restaurant->id_menu; ?>>
                    <i class="bi bi-cart3"></i>
                    </a>
                    <a class="btn btn-sm btn-warning" href=<?= URI . "restaurants/modifier/" .$restaurant->id_menu; ?>>
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <a class="btn btn-sm btn-danger" href=<?= URI . 'restaurants/supprimer/' . $restaurant->id_menu; ?>>
                        <i class="bi bi-trash3-fill"></i>
                    </a>
                </td>
            </tr>
            </div>
        <?php } ?>
        
        </tbody>
    </table>
    
</div

