<?php

$sousTotal = 0;
$tps = 0;
$tvq = 0;
$fraisLivraison = 0;
$quantiteTotale=0;
$total = 0;

// Boucle à travers les restaurants dans le panier pour calculer le sous-total
foreach ($restaurants as $valueRestaurant) {
    $restaurant = $valueRestaurant[1];
    $quantite = $valueRestaurant[0];
    $sousTotal += $restaurant->prix * $quantite;
    $quantiteTotale += $quantite;
}

// Calcul des taxes (TPS et TVQ)
$tps = $sousTotal * 0.05; // TPS à 5%
$tvq = $sousTotal * 0.09975; // TVQ à 9.975%

if ($sousTotal < 500) {
    $fraisLivraison = $sousTotal * 0.04; // Frais de livraison de 5% pour les commandes de moins de 500$
}

// Calcul du total
$total = $sousTotal + $tps + $tvq + $fraisLivraison;
?>






<div class="container mt-5">
    <h1>Liste d'articles dans mon panier</h1>



    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Image</th>
            <th scope="col">Description</th>
            <th scope="col">Prix</th>
            <th scope="col">Quantite</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        

        <?php
        $cmpt = 1;
        foreach ($restaurants as $key => $valueRestaurant) {
            $restaurant = $valueRestaurant[1];
            $quantite = $valueRestaurant[0];
            ?>
            <form action="<?= URI . 'paniers/modifier/' . $restaurant->id_menu; ?>" method="post">
                <tr>
                    <th scope="row"><?= $cmpt++; ?></th>
                    <td>
                        <img height="100px" width="100px"
                             src=<?=
                        (isset($restaurant->chemin)) ?
                            URI . $restaurant->chemin :
                            URI . 'assets/télécharger.jpeg';

                        ?>></td>
                    <td><?= $restaurant->description; ?></td>
                    <td><?= $restaurant->prix; ?>$</td>
                    <td><input name="quantite" type="number" value=<?= $quantite; ?> name="quantite" min="0"
                           max="<?= $restaurant->quantite; ?>"></td>
                   
                    <td class="row">
                        <button type="submit" class="btn btn-sm btn-warning col" >
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        
                        <a class="btn btn-sm btn-danger col" href=<?= URI . 'paniers/supprimer/' . $restaurant->id_menu; ?>>
                            <i class="bi bi-trash3-fill"></i>
                        </a>

                        
                    </td>
                </tr>

                
            </form>
        <?php } ?>

        
        </tbody>
    </table>
    <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Total du Panier</h5>
            <p class="card-text">Quantite:  <?= $quantiteTotale;?></p>
            <p class="card-text">Sous-total: Ca$ <?= $sousTotal;?></p>
            <p class="card-text">TPS: Ca$  <?= $tps;?></p>
            <p class="card-text">TVQ: Ca$  <?= $tvq;?></p>
            <p class="card-text">Frais de livraison: Ca$ <?= $fraisLivraison;?></p>
            <h4 class="card-text">Total: Ca$ <?= $total;?></h4>
            <form action="<?= URI . 'commandes/valider'; ?>" method="post"> <!-- Assurez-vous que l'action du formulaire pointe vers la méthode de validation de la commande -->
    <!-- Autres éléments de votre formulaire -->

    <!-- Champs cachés pour stocker le prix total et la quantité totale -->
    <input type="hidden" name="total" value="<?= $total; ?>">
    <input type="hidden" name="quantiteTotale" value="<?= $quantiteTotale; ?>">

    <!-- Bouton de soumission -->
    <button type="submit" class="btn btn-primary" name="valider">Valider</button>
</form>
            <a href="#" class="btn btn-primary disabled">Vider</a>
          </div>
        </div>

        <br>
      </div>
      <?php
if(isset($_SESSION['Utilisateur'])){
    ?>
    <div id="paypal-button-container"></div>
    <?php
}

?>
</div>






<script src="https://www.paypal.com/sdk/js?client-id=AZRseyC57xa-sZwQ-ro_w3r7d0F57am82ho6_TKuo6PYNIAVh25PseeLNtzCTRZDiOdMhM96vkCYvFLA&components=buttons"></script>
    

<script>



paypal.Buttons({
   
    createOrder: function (data, actions) {
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: '0.01'
                }
            }]
        });
    },
   
    onApprove: async (data, actions) => {
        
        window.location.href = "<?= URI . 'commandes/commander'; ?>";

     
        const order = await actions.order.capture();
        console.log(order);
        alert('Transaction complétée par ' + order.payer.name.given_name);
    }
}).render('#paypal-button-container');

</script>